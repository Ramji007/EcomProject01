package com.niit.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.SupplierDAO;

import com.niit.shoppingcart.model.Supplier;

public class SupplierController {
	
	@Autowired
	private SupplierDAO supplierDAO ;
	@Autowired
	private Supplier supplier ;
	
	@RequestMapping(value="/suppliers", method=RequestMethod.GET)
	public String getListSupplier(Model model){
		
		model.addAttribute("supplier", new Supplier());
		model.addAttribute("supplierList", this.supplierDAO.list());
		return "supplier" ;
		
	}
	
	@RequestMapping(value="/suppliers/add" , method=RequestMethod.POST)
	public String addSupplier(@ModelAttribute("Supplier")  Supplier supplier){
		
		supplierDAO.save(supplier);
		return "redirect:/suppliers";		
	}
	
	@RequestMapping("supplier/remove/{id}")
	public ModelAndView removeSupplier(@PathVariable("id") String id)
	{
		supplier = supplierDAO.get(id);
		ModelAndView mv =new ModelAndView("supplier");
		if(supplier== null)
		{
			mv.addObject("error Mesage", "could not delete the supplier");
		}
		else
		{
			supplierDAO.delete(supplier);
		}
		return mv;
	}
	

	@RequestMapping("supplier/edit/{id}")
	public ModelAndView editSupplier(@ModelAttribute("supplier") Supplier supplier)
	{
		
		ModelAndView mv = new ModelAndView();
		if(supplierDAO.get(supplier.getId()) != null)
		{
			supplierDAO.update(supplier);
			mv.addObject("message", "successfully updated ");
		}
		else
		{
			mv.addObject("errorMessage","Could not update the record");
		}
		return mv ;
	}
		
		
	
	

}
