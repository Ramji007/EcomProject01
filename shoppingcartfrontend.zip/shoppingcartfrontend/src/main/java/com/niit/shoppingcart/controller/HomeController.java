package com.niit.shoppingcart.controller;



import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;

import com.niit.shoppingcart.dao.UserDetailsDAO;
import com.niit.shoppingcart.model.UserDetails;

@Controller
public class HomeController {

/*@RequestMapping("/") // ctrl +shift + ?
public String home()
{
	return "Home";
}*/
	@Autowired
	CategoryDAO categoryDAO ;
	@Autowired
	Category category;
	@Autowired
	UserDetailsDAO userdetailsDAO ;
	@Autowired
	UserDetails userdetails;
	
	// if you want to navigate to other page with carrying the data 
	@RequestMapping("/")
	public ModelAndView onLoad(HttpSession session){
		ModelAndView mv = new ModelAndView("/Home");
		
		//session.setAttribute("category", category);
		//session.setAttribute("categoryList", categoryDAO.list());
		mv.addObject("message", "thank you for visiting");
		//List<Category> categoryList = categoryDAO.list();
		//mv.addObject("categoryList",categoryList);
		//System.out.println("+++++++size+++++++ :"+categoryList.size());
		return mv ;
	}
	
	@RequestMapping("/LoginHere")
	public ModelAndView loginHere()
	{
		ModelAndView mv = new ModelAndView("/Login");
		mv.addObject("userDetails", userdetails);
		mv.addObject("isUserClickedLoginHere", "true");
		return mv;
	}
	
	@RequestMapping("/registerHere")
	public ModelAndView registerhere(){
		ModelAndView mv = new ModelAndView("/Register");
		mv.addObject("userDetails", userdetails);
		mv.addObject("userClickedRegistrationHere","true");
		return mv ;
	}
	

	
	@RequestMapping(value = "/registerSuccess",method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute UserDetails userdetails)
	{
		ModelAndView mv = new ModelAndView("/RegisterSuccess");
		if(userdetailsDAO.get(userdetails.getId())==null)
		{
			System.out.println("+++++inside Save method++++");
			userdetailsDAO.get(userdetails.getId());
			System.out.println("++++getid is+++++"+userdetails.getId());
			userdetailsDAO.save(userdetails);
			mv.addObject("successMessage","you are successfully register");
		}
		else
		{
			mv.addObject("msg", "user exist with this id");
		}
		
		mv.addObject("isUserClickedSubmit", "true");
		return mv;
	}


	
}
