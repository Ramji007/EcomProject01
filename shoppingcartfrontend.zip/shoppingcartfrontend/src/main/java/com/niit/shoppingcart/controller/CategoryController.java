package com.niit.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.util.Util;



@Controller
public class CategoryController {
	@Autowired
	private CategoryDAO categoryDAO;
	@Autowired
	private Category category ;
	
	@RequestMapping(value="/categories" , method=RequestMethod.GET)
	public String getListCategories(Model model){
		
		model.addAttribute("category", category);
		model.addAttribute("categoryList", this.categoryDAO.list());
		return "category";		
	}
	
	@RequestMapping(value="/addcategory" , method=RequestMethod.GET)
	public String addCategory(@ModelAttribute("category") Category category){
		
		//String newID = Util.removeComma(name);
		//category.setId("id");
		categoryDAO.save(category);
		return "category";
	}
	
	@RequestMapping("category/remove/{id}") 
	public ModelAndView deleteCategory(@PathVariable("id") String id) throws Exception
	{
		
		category = categoryDAO.get(id);
		ModelAndView mv = new ModelAndView("category");
		 if(category==null){
			 mv.addObject("error Message", "could not delete the category");
		 }else{
			 categoryDAO.delete(category); 
		 }
		
		return mv;
	}
	
	@RequestMapping("category/edit/{id}")
	public ModelAndView editCategory(@ModelAttribute("category") Category category)
	{
		ModelAndView mv = new ModelAndView();
		if(categoryDAO.get(category.getId()) != null)
		{
			categoryDAO.update(category);
			mv.addObject("message", "successfully updated ");
		}
		else
		{
			mv.addObject("errorMessage","Could not update the record");
		}
	return mv;
	}
	
	
}


