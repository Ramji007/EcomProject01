package com.niit.shoppingcart.util;

public class Util {

	
	public String removeComma(String name){
		return name.replace(",", "");
		
	}
}
