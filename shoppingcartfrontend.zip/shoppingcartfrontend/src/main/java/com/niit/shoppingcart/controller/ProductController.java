package com.niit.shoppingcart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingcart.dao.CategoryDAO;
import com.niit.shoppingcart.dao.ProductDAO;
import com.niit.shoppingcart.dao.SupplierDAO;
import com.niit.shoppingcart.dao.UserDetailsDAO;
import com.niit.shoppingcart.model.Category;
import com.niit.shoppingcart.model.Product;
import com.niit.shoppingcart.model.Supplier;
import com.niit.shoppingcart.model.UserDetails;
import com.niit.shoppingcart.util.FileUtil;

public class ProductController {
	
	@Autowired
	private ProductDAO productDAO;
	@Autowired
	private Product product ;
	@Autowired
	private CategoryDAO categoryDAO ;
	@Autowired
	private Category category ;	
	@Autowired
	private Supplier supplier ;
	@Autowired
	private SupplierDAO supplierDAO;
	@Autowired
	private UserDetails userDetails ;
	@Autowired
	private UserDetailsDAO userDetailsDAO ;
	
	
	private String path="D:\\shoppingcart\\img" ;
	
	@RequestMapping(value="/product" , method=RequestMethod.GET)
	public String getListProduct(Model model){
		
		model.addAttribute("product", new Product());
		model.addAttribute("Supplier", new Supplier());
		model.addAttribute("Category", new Category());
		
		model.addAttribute("productList", this.productDAO.list());
		model.addAttribute("supplierList", this.supplierDAO.list());
		model.addAttribute("categoryList", this.categoryDAO.list());
		
		
		return "product" ;		
	}
	
	
	
	@RequestMapping(value="/product/add", method=RequestMethod.GET)
	public String addProduct(@ModelAttribute("product") Product product , @RequestParam("image")  MultipartFile file){
		
		Category category = categoryDAO.getByName(product.getCategory().getName());
		
		//Supplier supplier = supplierDAO.getByName(product.getSupplier().getName());
		
		product.setCategory(category);
		//product.setSupplier(supplier);
		
		product.setCategoryId(category.getId());
		product.setSupplierId(supplier.getId());
		
		productDAO.save(product);
		
		MultipartFile image = product.getImage();
		
		FileUtil.upload(path, file, product.getId()+".jpg");
		
		return "redirect:/Products";
		
	}
	
	
	@RequestMapping("product/remove/{id}") 
	public ModelAndView deleteProduct(@PathVariable("id") String id) throws Exception
	{
		
		product = productDAO.get(id);
		ModelAndView mv = new ModelAndView("product");
		 if(product==null){
			 mv.addObject("error Message", "could not delete the category");
		 }else{
			 productDAO.delete(product); 
		 }
		
		return mv;
	}
	
	@RequestMapping("product/edit/{id}")
	public ModelAndView editProduct(@ModelAttribute("product") Product product)
	{
		ModelAndView mv = new ModelAndView();
		if(productDAO.get(product.getId()) != null)
		{
			productDAO.update(product);
			mv.addObject("message", "successfully updated ");
		}
		else
		{
			mv.addObject("errorMessage","Could not update the record");
		}
	return mv;
	}
	
	
	
	
	

}
